<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<table border=1>
<?php echo e($share); ?>

<tr> <td>id</td>
<td>title</td>
<td>body</td>
<td>Edit</td>
<td>Delete</td>
</tr>
<?php $__currentLoopData = $share; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($value->id); ?></td>
<td><?php echo e($value->title); ?>

<td><?php echo e($value->body); ?></td>
</td>
<td><a href="<?php echo e(route('Share.edit',$value->id)); ?>">Edit</a></td>
<td><form action="<?php echo e(route('Share.destroy',$value->id)); ?>"   method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<button type="submit">Delete</button>
</form></td></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<body>
</body>
</html>