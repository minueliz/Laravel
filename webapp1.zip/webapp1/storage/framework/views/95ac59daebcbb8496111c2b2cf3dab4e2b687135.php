<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>


<?php $__env->startSection('content'); ?>
<h1>Home</h1>
<h2><?php echo e($titles); ?></h2>
<p>Amal Jyothi<p>
<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.minu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>