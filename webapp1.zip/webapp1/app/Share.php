<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Share extends Model
{
   public $fillable=[
   'title',
   'body'];
}

