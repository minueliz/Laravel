<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AjcController extends Controller
{
    //
}
