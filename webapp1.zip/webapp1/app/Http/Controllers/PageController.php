<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index()
    {
	  $name="minu";
	   // return view('pages.index',compact('name'));
	   return view('pages.index')->with('titles',$name);
    }
public function about()
    {
	    return view('pages.about');
    }
    public function service()
    {
	    return view('pages.service');
    }
}
